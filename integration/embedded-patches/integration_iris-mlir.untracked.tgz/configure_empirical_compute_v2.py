#!/usr/bin/env python3
"""Publish an explicit empirical selection from verified, frozen runtime inputs.

No measurements or qualification are invented here. The fit, source closure,
three-hart execution and timing sensitivity must already have passed.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
from urllib.parse import urlparse, unquote

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from spike.empirical_provider_v3 import document, experimental_empirical_simulator, runtime_binding_inputs, sha
from spike.empirical_launch_v2 import launcher_text
from spike.run_functional import COMPUTE, DMA, PIN


def archived_member(path, basename):
    """Hash the unique actual member without extracting archive paths."""
    matches = []
    with tarfile.open(path, 'r|*') as archive:
        for member in archive:
            if Path(member.name).name != basename:
                continue
            if not member.isfile():
                raise ValueError('Required archive member must be a regular file: ' + basename)
            digest = hashlib.sha256()
            with archive.extractfile(member) as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    digest.update(block)
            matches.append({'name': member.name, 'bytes': member.size, 'sha256': digest.hexdigest()})
    if len(matches) != 1:
        raise ValueError('Unique actual archived member required: ' + basename)
    return matches[0]


def verified_reference(binding, run_path, analysis_path, observability_path):
    """Bind fitted labels to the exact successful managed experiment, not a fixed old run."""
    run_path, analysis_path, observability_path = [Path(p).resolve() for p in (run_path, analysis_path, observability_path)]
    declared = binding.get('reference', {})
    inputs = runtime_binding_inputs(binding)
    for field, path in [('run_manifest', run_path), ('analysis', analysis_path)]:
        if (declared.get(field) != str(path) or declared.get(field+'_sha256') != sha(path)
                or inputs.get(str(path)) != sha(path)):
            raise ValueError('Runtime binding must directly bind the actual reference '+field)
    run, analysis = document(run_path), document(analysis_path)
    capture = run.get('capture', {})
    allowed = {'iris.buffered_fitting_archive_analysis.v1': 'buffered_fitting_campaign_v1',
               'iris.buffered_priority_fitting_archive_analysis.v2': 'buffered_priority_fitting_campaign_v2',
               'iris.compute_fitting_archive_analysis.v1': 'compute_fitting_campaign_v1'}
    if (analysis.get('schema') not in allowed or run.get('campaign_role') != allowed[analysis['schema']]
            or run.get('fitting_only') is not True or run.get('global_heldout') is not False
            or analysis.get('fitting_only') is not True or analysis.get('global_heldout') is not False):
        raise ValueError('Recognized fitting-only reference required; held-out labels cannot calibrate this package')
    if (run.get('status') != 'completed_uncertified' or run.get('cleanup_status') != 'passed'
            or run.get('error') is not None or run.get('cleanup_error') is not None
            or capture.get('status') != 'captured' or run.get('require_regions') is not True
            or run.get('require_goldens') is not True
            or any(analysis.get(k) is not True for k in ('pass','archive_verified','managed_run_passed','functional_checks_passed'))
            or analysis.get('current_run_manifest_sha256') != sha(run_path)
            or analysis.get('archive_sha256') != capture.get('archive_sha256')
            or declared.get('capture_archive_sha256') != capture.get('archive_sha256')
            or declared.get('elf_sha256') != run.get('elf_sha256')):
        raise ValueError('Successful exact managed/reference ELF, archive analysis and owned cleanup required')
    if ([(c.get('task'), c.get('status')) for c in run.get('commands', [])] !=
            [('kill','passed'),('infrasetup','passed'),('runworkload','passed'),('kill','passed')]):
        raise ValueError('Reference must use the complete four managed phases')
    count=run.get('expected_regions')
    if (type(count) is not int or count<=0 or len(run.get('regions', []))!=count
            or analysis.get('guest_proof', {}).get('regions')!=count):
        raise ValueError('Every expected actual reference region must be independently checked')
    archive=Path(capture['archive']).resolve()
    if sha(archive)!=capture['archive_sha256']:raise ValueError('Reference archive bytes changed')
    observation=document(observability_path)
    materials={str(p):sha(p) for p in (run_path,analysis_path,observability_path,archive)}
    artifact_paths = {}
    for field in ('image','driver'):
        artifact=run[field];uri=urlparse(artifact['uri'])
        if uri.scheme!='file':raise ValueError('Exact local archived image/driver required')
        path=Path(unquote(uri.path)).resolve()
        if sha(path)!=artifact['sha256'] or observation['input_sha256'].get(str(path))!=artifact['sha256']:
            raise ValueError('Reference image/driver differs from inspected instrumentation')
        materials[str(path)]=artifact['sha256']
        artifact_paths[field] = path
    bit = archived_member(artifact_paths['image'], 'firesim.bit')
    driver = archived_member(artifact_paths['driver'], 'FireSim-corigine_mimicturbo_gt')
    for field, actual in (('image_members', bit), ('driver_members', driver)):
        declared_members = [entry for entry in observation[field]
                            if Path(entry['name']).name == Path(actual['name']).name]
        if declared_members != [actual]:
            raise ValueError('Inspected inner archive member differs from actual bytes: ' + field)
    if observation.get('driver_binary_sha256') != driver['sha256']:
        raise ValueError('Inspected driver binary identity differs from actual bundle member')
    reference={'image_archive_sha256':run['image']['sha256'],'bitstream_sha256':bit['sha256'],
        'driver_sha256':driver['sha256'],'capture_archive_sha256':capture['archive_sha256'],
        'source_image_association_verified':False,'run_manifest':str(run_path),'run_manifest_sha256':sha(run_path),
        'analysis':str(analysis_path),'analysis_sha256':sha(analysis_path),'elf_sha256':run['elf_sha256'],
        'independently_checked_regions':count,
        'interpretation':'Exact archived managed experiment; no loaded-bit readback or full source/image attestation.'}
    return reference,materials


def publish(native, uart, fixture, parameters, fit_report, runtime_binding,
            selftest, source_closure, output, reference_run, reference_analysis,
            launcher, launcher_selftest, launcher_python):
    paths = [Path(p).resolve() for p in (native, uart, fixture, parameters, fit_report,
                                       runtime_binding, selftest, source_closure)]
    native, uart, fixture, parameters, fit_report, runtime_binding, selftest, source_closure = paths
    output = Path(output).resolve()
    launcher, launcher_selftest, launcher_python = [Path(p).resolve() for p in
                                                    (launcher, launcher_selftest, launcher_python)]
    if output.exists(): raise ValueError('Fresh publication directory required')
    binding = document(runtime_binding); closure = document(source_closure); tested = document(selftest)
    if (closure.get('pass') is not True
            or closure.get('native_binary_sha256', closure.get('binary_sha256')) != sha(native)
            or closure.get('uart_library_sha256', closure.get('uart_sha256')) != sha(uart)
            or not closure.get('input_sha256')):
        raise ValueError('Independently verified byte-bound native/source closure required')
    for field, path in [('native_binary_sha256', native), ('uart_library_sha256', uart),
                        ('fixture_sha256', fixture), ('parameters_sha256', parameters),
                        ('fit_report_sha256', fit_report)]:
        if binding.get(field) != sha(path): raise ValueError('Runtime binding differs: ' + field)
    identities = {str(p): sha(p) for p in paths}
    template = ROOT / 'spike/empirical_launch_v2.py'
    if launcher.read_text() != launcher_text(native, sha(native), launcher_python, sha(launcher_python)):
        raise ValueError('Exact fatal-aware launcher rendering required')
    launched = document(launcher_selftest)
    if (launched.get('schema') != 'iris.empirical_fatal_launcher_selftest.v2' or launched.get('pass') is not True
            or launched.get('native_binary_sha256') != sha(native) or launched.get('launcher_sha256') != sha(launcher)
            or launched.get('fixture_sha256') != sha(fixture)):
        raise ValueError('Successful exact launcher selftest required')
    for path in (launcher, launcher_selftest, launcher_python, template, ROOT / 'spike/check_empirical_launcher_v2.py'):
        identities[str(path)] = sha(path)
    identities.update(runtime_binding_inputs(binding))
    for source in (closure, tested, launched):
        for key in ('input_sha256', 'evidence_sha256', 'output_sha256'):
            for name, expected in source.get(key, {}).items():
                path = Path(name)
                if not path.is_absolute() or sha(path) != expected:
                    raise ValueError('Source/selftest evidence changed: ' + name)
                if str(path) in identities and identities[str(path)] != expected:
                    raise ValueError('Conflicting input identity: ' + name)
                identities[str(path)] = expected
    if closure.get('schema') != 'iris.empirical.source_closure_verification.v1':
        raise ValueError('Recognized empirical source verification receipt required')
    snapshot_path = source_closure.with_name('manifest.json')
    inventory_path = source_closure.with_name('source-inventory.json')
    snapshot = document(snapshot_path); inventory = document(inventory_path)
    if (snapshot.get('schema') != 'iris.empirical.fast_source_capsule.v1'
            or snapshot.get('base_commit') != PIN
            or closure.get('manifest_sha256') != sha(snapshot_path)
            or snapshot.get('binary_sha256') != sha(native)
            or snapshot.get('uart_sha256') != sha(uart)
            or closure.get('archived_sources_verified') != len(inventory)):
        raise ValueError('Source inventory, verification receipt and native epoch disagree')
    materials = dict(snapshot['input_sha256'])
    materials.update({str(snapshot_path.parent / name): digest
                      for name, digest in snapshot['artifact_sha256'].items()})
    for name, expected in inventory.items():
        relative = Path(name)
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('Invalid archived source path')
        materials[str(snapshot_path.parent / 'src' / relative)] = expected
    for name, expected in materials.items():
        path = Path(name)
        if not path.is_absolute() or sha(path) != expected:
            raise ValueError('Frozen source material changed: ' + name)
        if str(path) in identities and identities[str(path)] != expected:
            raise ValueError('Conflicting source material identity: ' + name)
        identities[str(path)] = expected
    run_path, observation_path = Path(reference_run).resolve(), Path(reference_analysis).resolve()
    observability_path = ROOT/'build/firesim-observability-archived-driver-v3/report.json'
    hardware_path = ROOT/'hardware/manifest.json'
    reference, reference_materials = verified_reference(binding, run_path, observation_path, observability_path)
    identities.update(reference_materials)
    hardware = document(hardware_path)
    rom = ROOT / 'board/evidence/bootrom.rv64.img'; dtb = ROOT / 'board/build/iris.dtb'
    provider = ROOT / 'spike/empirical_provider_v3.py'
    adapter = Path(__file__).with_name('simulator.py').resolve()
    for path in (Path(__file__).resolve(), provider, adapter, rom, dtb,
                 hardware_path, run_path, observation_path, observability_path):
        identities[str(path)] = sha(path)
    source_pins = {name: value['commit'] for name, value in hardware['repositories'].items()}
    source_pins['spike'] = PIN
    for repository in hardware['repositories'].values():
        if 'tracked_diff' in repository:
            path = hardware_path.parent / repository['tracked_diff']
            if sha(path) != repository['tracked_diff_sha256']:
                raise ValueError('Recorded hardware source patch changed: ' + str(path))
            identities[str(path)] = sha(path)
    libraries = {}
    for image in (native, uart, launcher_python):
        linked = subprocess.check_output(['/usr/bin/ldd', str(image)], text=True)
        if 'not found' in linked: raise ValueError('Missing native runtime library')
        for name in re.findall(r'(?:=>\s*)?(/[^\s()]+)', linked):
            path = Path(name).resolve()
            if path.is_file(): libraries[str(path)] = sha(path)
    if not libraries: raise ValueError('Expected native dynamic library closure missing')
    identities.update(libraries)
    for name, pin in source_pins.items():
        if len(pin) != 40 or any(c not in '0123456789abcdef' for c in pin):
            raise ValueError('Full source pin required: ' + name)
    manifest = {'schema': 'iris.empirical_simulator.v1', 'mode': 'experimental_fpga_empirical',
        'binary': str(launcher), 'binary_sha256': sha(launcher),
        'native_binary': str(native), 'native_binary_sha256': sha(native),
        'uart_library': str(uart), 'uart_library_sha256': sha(uart), 'native_device_abi': 4,
        'model_provider': str(provider), 'calibration_identity': binding['calibration_identity'],
        'runtime_environment': {name: os.environ.get(name) for name in ('LD_LIBRARY_PATH', 'LD_PRELOAD', 'LD_AUDIT')},
        'isa_extensions': ['zvt32t', 'zvti8i32mm', 'zvtofp8fmm'],
        'per_hart_isa': {'0': COMPUTE, '1': COMPUTE, '2': DMA}, 'matrix_hart_ids': [0, 1],
        'memory_regions': [[0x70000000, 0x40000], [0x80000000, 0x100000000], [0x580000000, 0x20000]],
        'launch_args': ['--iris-vme', '--extlib=' + str(uart), '--device=sifive_uart,0x10020000',
                        '--iris-bootrom=' + str(rom), '--dtb=' + str(dtb),
                        '--iris-timing-fixture=' + str(fixture)],
        'calibration': {'parameters': str(parameters), 'parameters_sha256': sha(parameters),
            'fixture': str(fixture), 'fixture_sha256': sha(fixture),
            'fit_report': str(fit_report), 'fit_report_sha256': sha(fit_report),
            'runtime_binding': str(runtime_binding), 'runtime_binding_sha256': sha(runtime_binding),
            'reference': reference},
        'selftest': {'receipt': str(selftest), 'sha256': sha(selftest)},
        'native_launcher': {'kind': 'automatic-fatal-ELF-v2', 'template': str(template),
            'template_sha256': sha(template), 'python': str(launcher_python),
            'python_sha256': sha(launcher_python), 'selftest': str(launcher_selftest),
            'selftest_sha256': sha(launcher_selftest),
            'scope': 'Automatic fatal symbol resolution from unstripped RV64 ELF; ordinary traps remain recoverable.',
            'isolated_python': True, 'parser_policy':'fatal-ELF-exec-v2', 'python_standard_library_closure_verified': False},
        'built_from': {'source_snapshot_verified': True, 'receipt': str(source_closure),
            'receipt_sha256': sha(source_closure), 'source_pins': source_pins,
            'source_manifest': str(snapshot_path), 'source_manifest_sha256': sha(snapshot_path),
            'archived_source_files': len(inventory),
            'runtime_libraries_sha256': libraries,
            'source_image_association_verified': False},
        'qualification': {'rtl_certified': False, 'accuracy_2percent_certified': False,
                          'whole_model_certified': False, 'zephyr_smp_certified': False},
        'timing_scope': binding.get('timing_scope', 'Experimental effective service costs; consult fit report and held-out errors.'),
        'input_sha256': identities}
    # Validate before publication; preserve a refused receipt rather than expose
    # it through the conventional manifest.json selection path.
    output.mkdir(parents=True)
    candidate = output / 'candidate.json'; candidate.write_text(json.dumps(manifest, indent=2) + '\n')
    verified = experimental_empirical_simulator(candidate)
    if verified.get('available') is not True:
        (output / 'verification.json').write_text(json.dumps(verified, indent=2) + '\n')
        raise ValueError(verified['reason'])
    final = output / 'manifest.json'; final.write_bytes(candidate.read_bytes())
    verified = experimental_empirical_simulator(final)
    (output / 'verification.json').write_text(json.dumps(verified, indent=2) + '\n')
    if verified.get('available') is not True:
        final.rename(output / 'refused-manifest.json')
        raise ValueError(verified['reason'])
    return final


def main():
    parser = argparse.ArgumentParser(__doc__)
    for name in ('native', 'uart', 'fixture', 'parameters', 'fit-report', 'runtime-binding',
                 'selftest', 'source-closure', 'output', 'reference-run', 'reference-analysis',
                 'launcher', 'launcher-selftest', 'launcher-python'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    print(publish(args.native, args.uart, args.fixture, args.parameters, args.fit_report,
                  args.runtime_binding, args.selftest, args.source_closure, args.output, args.reference_run, args.reference_analysis,
                  args.launcher, args.launcher_selftest, args.launcher_python))


if __name__ == '__main__': main()
