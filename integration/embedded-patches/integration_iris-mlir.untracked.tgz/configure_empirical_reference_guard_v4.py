#!/usr/bin/env python3
"""Guard-only successor: preserve every selected runtime byte and prior execution."""
import argparse,copy,hashlib,importlib.util,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def module(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
SEMANTIC_KEYS=['available','binary','binary_sha256','native_binary','native_binary_sha256','native_device_abi','automatic_fatal_handler_resolution','isa_extensions','per_hart_isa','matrix_hart_ids','memory_regions','launch_args','timing_available','timing_status','empirical_fit_available','timing_calibrated','rtl_certified','accuracy_2percent_certified','zephyr_smp_certified','whole_model_certified','timing_scope','validation_metrics','functional_scope']
def publish(parent,expected,out):
 parent=Path(parent).resolve();out=Path(out).resolve()
 if out.exists()or sha(parent)!=expected:raise ValueError('Fresh output and exact expected parent hash required')
 original=load(parent);oldpath=Path(original['model_provider']);old=module(oldpath,'guard_v4_parent_provider');positive=old.experimental_empirical_simulator(parent)
 if positive.get('available')is not True:raise ValueError('Original provider refused parent: '+str(positive.get('reason')))
 provider=ROOT/'spike/empirical_provider_v4.py';new=module(provider,'guard_v4_successor_provider');child=copy.deepcopy(original);child['model_provider']=str(provider);child['input_sha256'][str(provider)]=sha(provider);child['input_sha256'][str(Path(__file__).resolve())]=sha(__file__);child['input_sha256'][str(parent)]=sha(parent)
 reference=child['calibration']['reference'];run=load(reference['run_manifest']);observation=run['observability_audit'];path=Path(observation['report']).resolve()
 if sha(path)!=observation['sha256']or child['input_sha256'].get(str(path))!=sha(path):raise ValueError('Already-bound actual observability report required')
 reference['observability_report']=str(path);reference['observability_report_sha256']=sha(path)
 child['reference_guard_lineage']=dict(schema='iris.guard_only_reference_successor.v1',parent_manifest=str(parent),parent_manifest_sha256=expected,parent_provider=str(oldpath),parent_provider_sha256=sha(oldpath),policy='bound-managed-reference-identities-v4',native_or_fixture_or_parameter_changes=False,old_execution_receipts_relabelled=False,previous_execution_scope='Parent exact native/UART/fixture/gates remain historical; descriptor-only guard equivalence is checked separately; new smoke execution uses this manifest.')
 invariant=['binary','binary_sha256','native_binary','native_binary_sha256','uart_library','uart_library_sha256','native_device_abi','native_launcher','calibration_identity','runtime_environment','isa_extensions','per_hart_isa','matrix_hart_ids','memory_regions','launch_args','selftest','built_from','qualification','timing_scope']
 if any(child[k]!=original[k]for k in invariant):raise ValueError('Guard-only publisher changed a runtime/source claim')
 for k in ['fixture','fixture_sha256','parameters','parameters_sha256','fit_report','fit_report_sha256','runtime_binding','runtime_binding_sha256']:
  if child['calibration'][k]!=original['calibration'][k]:raise ValueError('Guard-only calibration changed')
 if any(reference[k]!=v for k,v in original['calibration']['reference'].items()):raise ValueError('Existing reference metadata changed')
 new.validate_reference_metadata(child,load(child['calibration']['runtime_binding']));out.mkdir(parents=True);target=out/'manifest.json';target.write_text(json.dumps(child,indent=2)+'\n');verified=new.experimental_empirical_simulator(target)
 if verified.get('available')is not True:raise ValueError('New provider refused child: '+str(verified.get('reason')))
 if any(positive.get(k)!=verified.get(k)for k in SEMANTIC_KEYS):raise ValueError('Runtime descriptor semantics changed beyond provenance guard')
 (out/'parent-descriptor.json').write_text(json.dumps(positive,indent=2)+'\n');(out/'new-descriptor.json').write_text(json.dumps(verified,indent=2)+'\n')
 report=dict(schema='iris.guard_only_reference_publication.v1',**{'pass':True},parent_manifest=str(parent),parent_manifest_sha256=expected,manifest=str(target),manifest_sha256=sha(target),runtime_descriptor_equivalence_keys=SEMANTIC_KEYS,runtime_descriptor_equivalent=True,unchanged_runtime_native_uart_fixture_parameters_binding_launcher_ISAs_memory_launch_args=True,parent_execution_receipts_preserved_not_relabelled=True,new_execution_performed=False,hardware_contacted=False,activation_performed=False,input_sha256={str(p):sha(p)for p in [parent,oldpath,provider,Path(__file__).resolve(),path]},output_sha256={p.name:sha(p)for p in out.iterdir()if p.is_file()});(out/'publication.json').write_text(json.dumps(report,indent=2)+'\n');return report
if __name__=='__main__':
 p=argparse.ArgumentParser(__doc__);p.add_argument('--parent',type=Path,required=True);p.add_argument('--expected-parent-sha256',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();r=publish(a.parent,a.expected_parent_sha256,a.output);print(json.dumps({k:r[k]for k in ['pass','manifest','manifest_sha256','runtime_descriptor_equivalent']}))
