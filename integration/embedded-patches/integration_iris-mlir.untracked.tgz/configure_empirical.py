#!/usr/bin/env python3
"""Publish an explicit empirical selection from verified, frozen runtime inputs.

No measurements or qualification are invented here. The fit, source closure,
three-hart execution and timing sensitivity must already have passed.
"""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from spike.empirical_provider import document, experimental_empirical_simulator, runtime_binding_inputs, sha
from spike.run_functional import COMPUTE, DMA, PIN


def publish(native, uart, fixture, parameters, fit_report, runtime_binding,
            selftest, source_closure, output):
    paths = [Path(p).resolve() for p in (native, uart, fixture, parameters, fit_report,
                                       runtime_binding, selftest, source_closure)]
    native, uart, fixture, parameters, fit_report, runtime_binding, selftest, source_closure = paths
    output = Path(output).resolve()
    if output.exists(): raise ValueError('Fresh publication directory required')
    binding = document(runtime_binding); closure = document(source_closure); tested = document(selftest)
    if (closure.get('pass') is not True
            or closure.get('native_binary_sha256', closure.get('binary_sha256')) != sha(native)
            or closure.get('uart_library_sha256', closure.get('uart_sha256')) != sha(uart)
            or not closure.get('input_sha256')):
        raise ValueError('Independently verified byte-bound native/source closure required')
    for field, path in [('native_binary_sha256', native), ('uart_library_sha256', uart),
                        ('fixture_sha256', fixture), ('parameters_sha256', parameters),
                        ('fit_report_sha256', fit_report)]:
        if binding.get(field) != sha(path): raise ValueError('Runtime binding differs: ' + field)
    identities = {str(p): sha(p) for p in paths}
    identities.update(runtime_binding_inputs(binding))
    for source in (closure, tested):
        for key in ('input_sha256', 'evidence_sha256'):
            for name, expected in source.get(key, {}).items():
                path = Path(name)
                if not path.is_absolute() or sha(path) != expected:
                    raise ValueError('Source/selftest evidence changed: ' + name)
                if str(path) in identities and identities[str(path)] != expected:
                    raise ValueError('Conflicting input identity: ' + name)
                identities[str(path)] = expected
    if closure.get('schema') != 'iris.empirical.source_closure_verification.v1':
        raise ValueError('Recognized empirical source verification receipt required')
    snapshot_path = source_closure.with_name('manifest.json')
    inventory_path = source_closure.with_name('source-inventory.json')
    snapshot = document(snapshot_path); inventory = document(inventory_path)
    if (snapshot.get('schema') != 'iris.empirical.fast_source_capsule.v1'
            or snapshot.get('base_commit') != PIN
            or closure.get('manifest_sha256') != sha(snapshot_path)
            or snapshot.get('binary_sha256') != sha(native)
            or snapshot.get('uart_sha256') != sha(uart)
            or closure.get('archived_sources_verified') != len(inventory)):
        raise ValueError('Source inventory, verification receipt and native epoch disagree')
    materials = dict(snapshot['input_sha256'])
    materials.update({str(snapshot_path.parent / name): digest
                      for name, digest in snapshot['artifact_sha256'].items()})
    for name, expected in inventory.items():
        relative = Path(name)
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('Invalid archived source path')
        materials[str(snapshot_path.parent / 'src' / relative)] = expected
    for name, expected in materials.items():
        path = Path(name)
        if not path.is_absolute() or sha(path) != expected:
            raise ValueError('Frozen source material changed: ' + name)
        if str(path) in identities and identities[str(path)] != expected:
            raise ValueError('Conflicting source material identity: ' + name)
        identities[str(path)] = expected
    # The reference is the actually archived v12 fitting run, not an attestation
    # that current source checkouts built that image or a loaded-bit readback.
    run_path = ROOT / 'runs/fpga-user-authorized-v12/broad-fit/run.json'
    observation_path = ROOT / 'build/fpga-fit-observations-v1/report.json'
    observability_path = ROOT / 'build/firesim-observability-archived-driver-v3/report.json'
    hardware_path = ROOT / 'hardware/manifest.json'
    reference_run = document(run_path); observation = document(observation_path)
    observability = document(observability_path); hardware = document(hardware_path)
    if (reference_run.get('cleanup_error') is not None or reference_run.get('error') is not None
            or reference_run.get('capture', {}).get('status') != 'captured'
            or observation.get('regions') != 6750
            or observation['source_archive_sha256'] != reference_run['capture']['archive_sha256']):
        raise ValueError('Verified actual 6750-region FPGA reference required')
    bits = [entry['sha256'] for entry in observability['image_members'] if entry['name'].endswith('/firesim.bit')]
    if len(bits) != 1: raise ValueError('Unique archived image bitstream required')
    reference = {'image_archive_sha256': reference_run['image']['sha256'], 'bitstream_sha256': bits[0],
        'driver_sha256': observability['driver_binary_sha256'],
        'capture_archive_sha256': observation['source_archive_sha256'],
        'source_image_association_verified': False,
        'interpretation': 'Exact managed/reference archive identities; independent loaded-bit readback and full source/image attestation remain unavailable.'}
    rom = ROOT / 'board/evidence/bootrom.rv64.img'; dtb = ROOT / 'board/build/iris.dtb'
    provider = ROOT / 'spike/empirical_provider.py'
    adapter = Path(__file__).with_name('simulator.py').resolve()
    for path in (Path(__file__).resolve(), provider, adapter, rom, dtb,
                 hardware_path, run_path, observation_path, observability_path):
        identities[str(path)] = sha(path)
    source_pins = {name: value['commit'] for name, value in hardware['repositories'].items()}
    source_pins['spike'] = PIN
    for repository in hardware['repositories'].values():
        if 'tracked_diff' in repository:
            path = hardware_path.parent / repository['tracked_diff']
            if sha(path) != repository['tracked_diff_sha256']:
                raise ValueError('Recorded hardware source patch changed: ' + str(path))
            identities[str(path)] = sha(path)
    libraries = {}
    for image in (native, uart):
        linked = subprocess.check_output(['/usr/bin/ldd', str(image)], text=True)
        if 'not found' in linked: raise ValueError('Missing native runtime library')
        for name in re.findall(r'(?:=>\s*)?(/[^\s()]+)', linked):
            path = Path(name).resolve()
            if path.is_file(): libraries[str(path)] = sha(path)
    if not libraries: raise ValueError('Expected native dynamic library closure missing')
    identities.update(libraries)
    for name, pin in source_pins.items():
        if len(pin) != 40 or any(c not in '0123456789abcdef' for c in pin):
            raise ValueError('Full source pin required: ' + name)
    manifest = {'schema': 'iris.empirical_simulator.v1', 'mode': 'experimental_fpga_empirical',
        'binary': str(native), 'binary_sha256': sha(native),
        'native_binary': str(native), 'native_binary_sha256': sha(native),
        'uart_library': str(uart), 'uart_library_sha256': sha(uart), 'native_device_abi': 4,
        'model_provider': str(provider), 'calibration_identity': binding['calibration_identity'],
        'runtime_environment': {name: os.environ.get(name) for name in ('LD_LIBRARY_PATH', 'LD_PRELOAD', 'LD_AUDIT')},
        'isa_extensions': ['zvt32t', 'zvti8i32mm', 'zvtofp8fmm'],
        'per_hart_isa': {'0': COMPUTE, '1': COMPUTE, '2': DMA}, 'matrix_hart_ids': [0, 1],
        'memory_regions': [[0x70000000, 0x40000], [0x80000000, 0x100000000], [0x580000000, 0x20000]],
        'launch_args': ['--iris-vme', '--extlib=' + str(uart), '--device=sifive_uart,0x10020000',
                        '--iris-bootrom=' + str(rom), '--dtb=' + str(dtb),
                        '--iris-timing-fixture=' + str(fixture)],
        'calibration': {'parameters': str(parameters), 'parameters_sha256': sha(parameters),
            'fixture': str(fixture), 'fixture_sha256': sha(fixture),
            'fit_report': str(fit_report), 'fit_report_sha256': sha(fit_report),
            'runtime_binding': str(runtime_binding), 'runtime_binding_sha256': sha(runtime_binding),
            'reference': reference},
        'selftest': {'receipt': str(selftest), 'sha256': sha(selftest)},
        'built_from': {'source_snapshot_verified': True, 'receipt': str(source_closure),
            'receipt_sha256': sha(source_closure), 'source_pins': source_pins,
            'source_manifest': str(snapshot_path), 'source_manifest_sha256': sha(snapshot_path),
            'archived_source_files': len(inventory),
            'runtime_libraries_sha256': libraries,
            'source_image_association_verified': False},
        'qualification': {'rtl_certified': False, 'accuracy_2percent_certified': False,
                          'whole_model_certified': False, 'zephyr_smp_certified': False},
        'timing_scope': binding.get('timing_scope', 'Experimental effective service costs; consult fit report and held-out errors.'),
        'input_sha256': identities}
    # Validate before publication; preserve a refused receipt rather than expose
    # it through the conventional manifest.json selection path.
    output.mkdir(parents=True)
    candidate = output / 'candidate.json'; candidate.write_text(json.dumps(manifest, indent=2) + '\n')
    verified = experimental_empirical_simulator(candidate)
    if verified.get('available') is not True:
        (output / 'verification.json').write_text(json.dumps(verified, indent=2) + '\n')
        raise ValueError(verified['reason'])
    final = output / 'manifest.json'; final.write_bytes(candidate.read_bytes())
    verified = experimental_empirical_simulator(final)
    (output / 'verification.json').write_text(json.dumps(verified, indent=2) + '\n')
    if verified.get('available') is not True:
        final.rename(output / 'refused-manifest.json')
        raise ValueError(verified['reason'])
    return final


def main():
    parser = argparse.ArgumentParser(__doc__)
    for name in ('native', 'uart', 'fixture', 'parameters', 'fit-report', 'runtime-binding',
                 'selftest', 'source-closure', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    print(publish(args.native, args.uart, args.fixture, args.parameters, args.fit_report,
                  args.runtime_binding, args.selftest, args.source_closure, args.output))


if __name__ == '__main__': main()
